import { PeriodeRPJMD, TujuanSasaranItem } from "../types";

export const INITIAL_PERIODE_LIST: PeriodeRPJMD[] = [
  {
    "id": "periode_2025_2030",
    "nama": "RPJMD Periode 2025 - 2030 (Teknokratik / Berjalan)",
    "tahunMulai": 2025,
    "tahunSelesai": 2030,
    "tahunList": [
      2025,
      2026,
      2027,
      2028,
      2029,
      2030
    ],
    "isAktif": true,
    "keterangan": "Rencana Pembangunan Jangka Menengah Daerah Kabupaten Tanggamus Tahun 2025-2030.",
    "createdAt": "2025-01-01T00:00:00Z"
  },
  {
    "id": "periode_2021_2026",
    "nama": "RPJMD Periode 2021 - 2026 (Transisi / Evaluasi)",
    "tahunMulai": 2021,
    "tahunSelesai": 2026,
    "tahunList": [
      2021,
      2022,
      2023,
      2024,
      2025,
      2026
    ],
    "isAktif": false,
    "keterangan": "Dokumen Rencana Pembangunan Jangka Menengah Daerah periode sebelumnya.",
    "createdAt": "2021-01-01T00:00:00Z"
  }
];

export const INITIAL_TUJUAN_SASARAN_ITEMS: TujuanSasaranItem[] = [
  {
    "id": "ts_2025_001",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 1,
    "misi": "Misi 1: Mewujudkan Sumber Daya Manusia yang Berkualitas, Berdaya Saing dan Berakhlak Mulia",
    "tujuan": "Meningkatkan Kualitas dan Pemerataan Akses Pendidikan Serta Kesehatan Masyarakat",
    "sasaran": "Meningkatnya Derajat Pendidikan, Kesehatan dan Daya Saing SDM Daerah",
    "indikator": "Indeks Pembangunan Manusia (IPM)",
    "satuan": "Poin",
    "targetTahunan": {
      "2025": 70.85,
      "2026": 71.5,
      "2027": 72.2,
      "2028": 72.9,
      "2029": 73.6,
      "2030": 74.3
    },
    "perangkatDaerahList": [
      "Bapperida",
      "Dinas Pendidikan",
      "Dinas Kesehatan",
      "Dinas Pemberdayaan Perempuan dan Perlindungan Anak"
    ],
    "bidangPengampu": "Bidang Pemerintahan dan Pembangunan Manusia (PPM)",
    "formula": "Komposit Angka Harapan Hidup, Rata-rata Lama Sekolah, Harapan Lama Sekolah, dan Pengeluaran Riil per Kapita (BPS)",
    "penanggungJawab": "Tim Koordinasi Peningkatan IPM Daerah",
    "keterangan": "Indikator Makro Utama Pengungkit Daya Saing Wilayah Kabupaten Tanggamus.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_002",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 1,
    "misi": "Misi 1: Mewujudkan Sumber Daya Manusia yang Berkualitas, Berdaya Saing dan Berakhlak Mulia",
    "tujuan": "Meningkatkan Kualitas dan Pemerataan Akses Pendidikan Serta Kesehatan Masyarakat",
    "sasaran": "Meningkatnya Derajat Pendidikan, Kesehatan dan Daya Saing SDM Daerah",
    "indikator": "Prevalensi Penurunan Stunting Balita Terintegrasi",
    "satuan": "%",
    "targetTahunan": {
      "2025": 13.5,
      "2026": 12,
      "2027": 10.8,
      "2028": 9.5,
      "2029": 8.5,
      "2030": 7.5
    },
    "perangkatDaerahList": [
      "Dinas Kesehatan",
      "Bapperida",
      "Dinas Pemberdayaan Masyarakat dan Desa (PMD)",
      "Dinas Sosial",
      "Dinas Pekerjaan Umum dan Penataan Ruang"
    ],
    "bidangPengampu": "Bidang PPM & Bidang Infraswil",
    "formula": "(Jumlah Balita Stunting Terdata / Total Balita Ditimbang) x 100% (e-PPGBM)",
    "penanggungJawab": "TPPS (Tim Percepatan Penurunan Stunting) Tanggamus",
    "keterangan": "Program prioritas nasional konvergensi 8 aksi percepatan penurunan stunting.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_003",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 1,
    "misi": "Misi 1: Mewujudkan Sumber Daya Manusia yang Berkualitas, Berdaya Saing dan Berakhlak Mulia",
    "tujuan": "Meningkatkan Kualitas dan Pemerataan Akses Pendidikan Serta Kesehatan Masyarakat",
    "sasaran": "Meningkatnya Derajat Pendidikan, Kesehatan dan Daya Saing SDM Daerah",
    "indikator": "Rata-rata Lama Sekolah (RLS) dan Harapan Lama Sekolah (HLS)",
    "satuan": "Tahun",
    "targetTahunan": {
      "2025": 8.45,
      "2026": 8.7,
      "2027": 8.95,
      "2028": 9.2,
      "2029": 9.5,
      "2030": 9.8
    },
    "perangkatDaerahList": [
      "Dinas Pendidikan",
      "Bapperida",
      "Kementerian Agama Tanggamus"
    ],
    "bidangPengampu": "Bidang PPM",
    "formula": "Rata-rata jumlah tahun yang dihabiskan penduduk usia 25 tahun ke atas dalam pendidikan formal",
    "penanggungJawab": "Dinas Pendidikan Kabupaten Tanggamus",
    "keterangan": "Peningkatan akses pendidikan nonformal dan kejar paket A, B, dan C.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_004",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 2,
    "misi": "Misi 2: Mewujudkan Tata Kelola Pemerintahan yang Bersih, Efektif, Akuntabel, dan Melayani",
    "tujuan": "Meningkatkan Akuntabilitas Kinerja dan Kualitas Pelayanan Publik Pemerintah Daerah",
    "sasaran": "Meningkatnya Tata Kelola Pemerintahan Daerah yang Efektif, Efisien, dan Berorientasi Hasil",
    "indikator": "Nilai Evaluasi Akuntabilitas Kinerja Instansi Pemerintah (SAKIP) Daerah",
    "satuan": "Nilai (Predikat)",
    "targetTahunan": {
      "2025": 75.5,
      "2026": 77,
      "2027": 79,
      "2028": 81,
      "2029": 83,
      "2030": 85
    },
    "perangkatDaerahList": [
      "Bapperida",
      "Inspektorat Daerah",
      "Bagian Organisasi Setda",
      "Badan Pengelolaan Keuangan dan Aset Daerah"
    ],
    "bidangPengampu": "Bidang PME (Pengendalian, Monev & Evaluasi)",
    "formula": "Hasil Evaluasi KemenPAN-RB atas Perencanaan, Pengukuran, Pelaporan, dan Evaluasi Kinerja Internal",
    "penanggungJawab": "Sekretaris Daerah & Kepala Bapperida",
    "keterangan": "Pencapaian Predikat BB menuju Predikat A (Sangat Baik).",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_005",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 2,
    "misi": "Misi 2: Mewujudkan Tata Kelola Pemerintahan yang Bersih, Efektif, Akuntabel, dan Melayani",
    "tujuan": "Meningkatkan Akuntabilitas Kinerja dan Kualitas Pelayanan Publik Pemerintah Daerah",
    "sasaran": "Meningkatnya Tata Kelola Pemerintahan Daerah yang Efektif, Efisien, dan Berorientasi Hasil",
    "indikator": "Indeks Sistem Pemerintahan Berbasis Elektronik (SPBE)",
    "satuan": "Indeks (Skala 1-5)",
    "targetTahunan": {
      "2025": 3.25,
      "2026": 3.5,
      "2027": 3.75,
      "2028": 4,
      "2029": 4.25,
      "2030": 4.5
    },
    "perangkatDaerahList": [
      "Dinas Komunikasi dan Informatika",
      "Bapperida",
      "Bagian Organisasi Setda",
      "Inspektorat Daerah"
    ],
    "bidangPengampu": "Diskominfo & Bidang Litbang/Inovasi Bapperida",
    "formula": "Nilai Komposit 47 Indikator Evaluasi SPBE Nasional KemenPAN-RB",
    "penanggungJawab": "Dinas Komunikasi dan Informatika Tanggamus",
    "keterangan": "Penerapan arsitektur SPBE terintegrasi dan tata kelola Satu Data Indonesia tingkat kabupaten.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_006",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 3,
    "misi": "Misi 3: Mewujudkan Pertumbuhan Ekonomi Daerah yang Inklusif, Berbasis Potensi Lokal dan Berkelanjutan",
    "tujuan": "Meningkatkan Pertumbuhan Ekonomi Berbasis Pertanian, Kelautan, Pariwisata, dan UMKM",
    "sasaran": "Meningkatnya Produktivitas dan Nilai Tambah Sektor Unggulan Daerah",
    "indikator": "Persentase Penurunan Angka Kemiskinan Makro Daerah",
    "satuan": "%",
    "targetTahunan": {
      "2025": 10.1,
      "2026": 9.5,
      "2027": 8.9,
      "2028": 8.3,
      "2029": 7.8,
      "2030": 7.2
    },
    "perangkatDaerahList": [
      "Bapperida",
      "Dinas Sosial",
      "Dinas Tanaman Pangan dan Hortikultura",
      "Dinas Perikanan",
      "Dinas Koperasi, UKM, Perindustrian dan Perdagangan",
      "Dinas Tenaga Kerja"
    ],
    "bidangPengampu": "Bidang Perekonomian dan SDA Bapperida",
    "formula": "Penurunan poin persentase jumlah penduduk miskin terhadap total penduduk (Survei BPS)",
    "penanggungJawab": "TKPK (Tim Koordinasi Penanggulangan Kemiskinan) Tanggamus",
    "keterangan": "Strategi pengurangan beban pengeluaran, peningkatan pendapatan, dan integrasi data P3KE.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_007",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 3,
    "misi": "Misi 3: Mewujudkan Pertumbuhan Ekonomi Daerah yang Inklusif, Berbasis Potensi Lokal dan Berkelanjutan",
    "tujuan": "Meningkatkan Pertumbuhan Ekonomi Berbasis Pertanian, Kelautan, Pariwisata, dan UMKM",
    "sasaran": "Meningkatnya Produktivitas dan Nilai Tambah Sektor Unggulan Daerah",
    "indikator": "Laju Pertumbuhan Produk Domestik Regional Bruto (PDRB) Sektor Pertanian & Perkebunan",
    "satuan": "%",
    "targetTahunan": {
      "2025": 4.8,
      "2026": 5.1,
      "2027": 5.4,
      "2028": 5.7,
      "2029": 6,
      "2030": 6.3
    },
    "perangkatDaerahList": [
      "Dinas Tanaman Pangan dan Hortikultura",
      "Dinas Perkebunan dan Peternakan",
      "Bapperida",
      "Dinas Koperasi, UKM, Perindustrian dan Perdagangan"
    ],
    "bidangPengampu": "Bidang Perekonomian dan SDA",
    "formula": "((PDRB ADHK Pertanian Th n - PDRB ADHK Pertanian Th n-1) / PDRB ADHK Pertanian Th n-1) x 100%",
    "penanggungJawab": "Dinas Tanaman Pangan dan Hortikultura",
    "keterangan": "Peningkatan nilai tambah hilirisasi komoditas unggulan Robusta Tanggamus dan Kakao.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_008",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 4,
    "misi": "Misi 4: Mewujudkan Pemerataan Pembangunan Infrastruktur yang Terintegrasi dan Berkelanjutan",
    "tujuan": "Meningkatkan Kualitas dan Konektivitas Infrastruktur Wilayah dan Tata Ruang yang Tangguh",
    "sasaran": "Meningkatnya Aksesibilitas dan Kelayakan Sarana Prasarana Wilayah Serta Ketahanan Bencana",
    "indikator": "Persentase Kemantapan Jalan Kabupaten Terkoneksi",
    "satuan": "%",
    "targetTahunan": {
      "2025": 74,
      "2026": 77,
      "2027": 80,
      "2028": 83,
      "2029": 86,
      "2030": 89
    },
    "perangkatDaerahList": [
      "Dinas Pekerjaan Umum dan Penataan Ruang",
      "Bapperida",
      "Dinas Perhubungan",
      "Badan Penanggulangan Bencana Daerah (BPBD)"
    ],
    "bidangPengampu": "Bidang Infrastruktur dan Wilayah (Infraswil)",
    "formula": "(Panjang Jalan Kabupaten Kondisi Baik & Sedang / Total Panjang Jalan Kabupaten) x 100%",
    "penanggungJawab": "Dinas PUPR Kabupaten Tanggamus",
    "keterangan": "Prioritas konektivitas sentra produksi pertanian pesisir dan dataran tinggi.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  },
  {
    "id": "ts_2025_009",
    "periodeId": "periode_2025_2030",
    "visi": "Terwujudnya Kabupaten Tanggamus yang Tangguh, Agamis, Mandiri, Unggul dan Sejahtera (TANGGAMUS TAMUS)",
    "misiNomor": 4,
    "misi": "Misi 4: Mewujudkan Pemerataan Pembangunan Infrastruktur yang Terintegrasi dan Berkelanjutan",
    "tujuan": "Meningkatkan Kualitas dan Konektivitas Infrastruktur Wilayah dan Tata Ruang yang Tangguh",
    "sasaran": "Meningkatnya Aksesibilitas dan Kelayakan Sarana Prasarana Wilayah Serta Ketahanan Bencana",
    "indikator": "Persentase Rumah Tangga Bersanitasi Layak dan Akses Air Minum Aman",
    "satuan": "%",
    "targetTahunan": {
      "2025": 86,
      "2026": 88.5,
      "2027": 91,
      "2028": 93.5,
      "2029": 96,
      "2030": 98.5
    },
    "perangkatDaerahList": [
      "Dinas Pekerjaan Umum dan Penataan Ruang",
      "Dinas Kesehatan",
      "Bapperida",
      "Dinas Lingkungan Hidup"
    ],
    "bidangPengampu": "Bidang Infraswil & Bidang PPM",
    "formula": "(Jumlah RT dengan Akses Air Minum Aman & Sanitasi Layak / Total RT) x 100%",
    "penanggungJawab": "Pokja PKP (Perumahan dan Kawasan Permukiman) Tanggamus",
    "keterangan": "Mendukung target Universal Access Sanitasi dan penurunan angka penyakit lingkungan.",
    "createdAt": "2025-01-15T08:00:00Z",
    "updatedAt": "2025-01-15T08:00:00Z"
  }
];
